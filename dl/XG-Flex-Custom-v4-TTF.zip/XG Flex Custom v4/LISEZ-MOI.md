# XG Flex Custom

Version 4 du 10 novembre 2026, construite sur XG Flex v3 (`XG-Flex-v3.zip`).

Les 98 styles de XG Flex avec trois séries de changements :

- huit glyphes redessinés pour se rapprocher de Lateral (6, 9, 2, a, Q, R, virgule et apostrophe), la virgule et l'apostrophe étant ensuite ramenées de 10 % vers la forme de Roboto ;
- la ponctuation et les signes de calcul dessinés sur les règles de Lateral : ? ! ¿ ¡ . : ; · … + − = × ÷ ± ≠ < > ≤ ≥ ;
- le crénage de X devant G, C, O et Q resserré, avec une seule valeur pour les quatre paires.

La famille s'appelle « XG Flex Custom ». Elle s'installe à côté de XG Flex et ne le remplace pas. Chaque font porte sa version à la fin de son champ Version : « XG Flex Custom 4 (2026-11-10) ».

## Contenu

- `Fonts/TTF/` : 98 fonts statiques `XGFlexCustom-<Style>.ttf` (7 chasses, 7 graisses, romain et italique), 898 glyphes chacune. Ce sont elles qu'on installe.
- `Fonts/WOFF2/` : les mêmes fonts en WOFF2, pour le web.
- `OFL.txt`, `FONTLOG.txt` : la licence (SIL Open Font License 1.1) et l'historique des modifications.
- `scripts/` : les scripts qui construisent les fonts et les contrôlent.

## Versions

- **Version 4** (10 novembre 2026) : X devant C, O et Q prend le crénage de X devant G, ainsi que devant Ø, Œ et les formes accentuées. Aucun contour ni aucune chasse ne change par rapport à la version 3.
- **Version 3** (10 novembre 2026) : virgule et apostrophe ramenées de 10 % vers Roboto ; ponctuation et signes de calcul ; approche gauche recalculée pour les 35 lettres et signes composés à partir d'un glyphe modifié ; les lettres accentuées bâties sur le a prennent toutes la réduction de chasse du a.
- **Version 2** (10 novembre 2026) : crénage entre X et G.
- **Version 1** (10 novembre 2026) : 6, 9, 2, a, Q, R, virgule et apostrophe.

## Ce qui change par rapport à XG Flex

### Glyphes refaits face à Lateral

- **6 et 9** : crosse longue finissant sur un court trait vertical coupé net. La panse est celle de XG Flex. Le blanc entre la coupe et la panse est partagé dans les proportions de Lateral.
- **2** : diagonale courbe.
- **a** : fût droit sans pied, coupe nette. Sa chasse est resserrée à droite pour que le fût ait la même approche que celui du u (10 millièmes en médiane, 82 au maximum en UltraWide Heavy).
- **Q** : la queue part du bord extérieur de l'anneau et ne rentre pas dans le contre-poinçon.
- **R** : jambe arrondie puis verticale, avec le léger ressaut au pied.
- **Virgule et apostrophe** : le trapèze aux cotes de Lateral est réécrit sur les dix points de la virgule de Roboto, puis chaque point fait 10 % du chemin vers elle. Les côtés prennent une légère courbe et la coupe du bas s'incline. La virgule partage 96,7 % de sa surface avec celle de Lateral en moyenne (98,7 % avant ce réglage), l'apostrophe 94,7 %.
- **Glyphes dérivés** : point-virgule, guillemets simples et doubles (‚ „ ‘ “ ”), chiffres proportionnels 6, 9 et 2. ŉ suit l'apostrophe.
- **Lettres accentuées** : les 33 lettres composées avec a ou R suivent les nouvelles formes. Celles qui sont bâties sur le a prennent la même réduction de chasse que lui.
- **Crénage de X devant G, C, O et Q** : dans XG Flex, X a la même valeur de crénage devant toutes les capitales rondes. La paire X G est réglée pour que le blanc entre les deux lettres soit celui mesuré dans Lateral, au resserrement global de XG Flex près. X C, X O et X Q reprennent exactement sa valeur, sans nouvelle mesure. Le crénage passe de −10 à −32 millièmes en Standard Regular et de −11 à −101 en Expanded Black. Il est resserré dans 82 styles, presque inchangé dans 11 et desserré de 5 à 13 millièmes dans 5 styles UltraCompressed très gras, où il était plus serré que chez Lateral. Les formes accentuées suivent, ainsi que Ø et Œ, qui avaient la même valeur dans la base : 44 capitales en tout. Le dessin des lettres ne change pas.

Deux alternatives sont incluses sur des codes privés, pour comparer :

- U+E000 : a avec pied (chasse de Lateral conservée).
- U+E001 : R à jambe droite, sans ressaut.

### Ponctuation et signes de calcul

Lateral Trial ne contient aucun de ces signes. Ils sont construits avec des mesures générales de Lateral (le rectangle de son point, le blanc entre le fût du i et son point, l'épaisseur de son trait d'union, la hauteur des capitales, le blanc entre les bras du E) et avec les graisses de XG Flex.

- **Points** de . : ; · et de ! ? ¡ ¿ ÷ : une ellipse de même surface que le rectangle du point de Lateral, posée au même endroit. Dans 29 styles lourds, l'élargissement est limité à 40 % du blanc que Lateral laisse entre deux points, et la hauteur compense. Les deux-points et le point-virgule accrochent leur point du haut à la hauteur d'x.
- **Points de suspension** : trois points au pas de trois points tapés, avec au minimum le blanc du i entre eux. Dans la base, les trois points n'étaient pas à égale distance et se chevauchaient dans les styles larges et lourds. La chasse du signe diminue dans les 98 styles : elle vaut de 40 % à 87 % de celle de la base.
- **!** : tige droite de la largeur des fûts des capitales, de la hauteur des capitales jusqu'au blanc du i au-dessus du point.
- **?** : boucle de XG Flex, tige à la graisse des capitales, même blanc au-dessus du point. Le cou garde la courbe de la base, étirée ou raccourcie pour rejoindre la tige.
- **¿ ¡** : demi-tour de ? et de !, à la profondeur que ces signes ont dans la base.
- **+ − = × ÷ ± ≠** : barres de l'épaisseur du trait d'union de Lateral, montants allégés dans la même proportion que ce trait d'union l'est par rapport à la barre du H. Les sept signes ont la même longueur de barre, la même chasse et le même axe (0,463 fois la hauteur des capitales, celui de XG Flex). La chasse de − × ÷ ± ≠ change dans 93 styles et celle de = dans 90, de 40 millièmes au plus. Le blanc du = est celui de la base tant qu'il suffit ; dans 22 styles lourds il est ouvert jusqu'à la moitié de l'épaisseur d'une barre, sans dépasser le blanc entre les bras du E de Lateral.
- **< > ≤ ≥** : deux traits coupés à la verticale, pointe émoussée comme dans la base. ≤ et ≥ posent le chevron sur une barre et grandissent jusqu'à la hauteur des capitales quand la place manque.

Tout le reste est celui de XG Flex : les autres glyphes, dont les points du i, du j et des accents, le trait d'union, les tirets, les parenthèses et les autres symboles, les autres paires de crénage et les métriques verticales.

## Limites connues

- La queue du Q est courte dans les styles étroits et fins.
- En Expanded et UltraWide à partir du Bold, la crosse assez carrée du 6 et du 9 rencontre une panse restée ovale.
- À 10 %, la virgule et l'apostrophe restent très proches de celles de Lateral.
- Les points de la ponctuation suivent les proportions de Lateral, alors que ceux du i, du j et des accents gardent la forme de la base. L'écart se voit en UltraWide Thin et Light, où le i porte un point plat (102 × 25 millièmes en Thin) et la phrase finit par un point haut (75 × 116).
- Deux points tapés à la suite sont très proches dans les styles étroits et lourds : 10 millièmes de blanc en UltraCompressed Heavy.
- Le signe ≠ est dense en Expanded et UltraWide, Black et Heavy : son trait dépasse peu des barres. Dans les italiques UltraCompressed lourds, il déborde de sa chasse à droite, de 108 millièmes au plus.
- Le signe × est allégé dans 22 styles lourds pour ne pas se boucher, jusqu'à 69 % de sa graisse en UltraCompressed Heavy Italic.
- ≤ et ≥ atteignent la hauteur des capitales en UltraWide Heavy, 95 millièmes plus haut que dans la base.
- Dans les italiques larges et lourds, la virgule du point-virgule dépasse de la chasse à gauche, de 104 millièmes au plus.
- Deux blancs sont plus serrés que chez Lateral : celui entre le fût et la jambe du R en UltraCompressed Black et Heavy (19 millièmes en Heavy, contre 25), et celui entre la boucle et la diagonale du 2 en Expanded Heavy et UltraWide Heavy (39 millièmes, contre 58 et 50).
- L'ouverture du 6 et du 9 vaut entre 0,80 et 1,26 fois celle de Lateral selon le style. La plus serrée est en Expanded Heavy : 22 millièmes pour le 6 et 21 pour le 9, contre 26.
- Le R à jambe droite garde la chasse du R par défaut : son approche droite est un peu plus large.
- Dans la base, 261 lettres composées (lettres accentuées, grec, cyrillique) n'ont pas la chasse de leur lettre de base dans une partie des styles, et cette lettre y est décalée vers la droite : ü, ñ ou ç dans les styles larges, à, á, â, ä et å dans 26 styles (58 millièmes au plus), ã dans 71 (156 au plus). XG Flex Custom garde ces écarts et ces décalages tels quels.
- Dans la base, í, ì, î et ï sont bâtis sur un i sans point qui n'a ni le fût ni la chasse du i dans les styles larges (fût de 81 millièmes contre 122 en UltraWide Regular). XG Flex Custom ne les modifie pas. Ces deux défauts sont signalés pour la base.
- Le crénage n'est recalé que pour X devant les capitales rondes. Les autres paires en diagonale (AV, KO, YG) gardent le crénage de XG Flex, plus lâche que celui de Lateral.
- X C, X O et X Q ont la valeur de crénage de X G, pas un blanc mesuré. Comme ces lettres n'ont pas exactement la même approche gauche, le blanc diffère un peu de celui de X G : de −10 à +6 millièmes pour X O, de −13 à +6 pour X C, de −18 à +12 pour X Q. Le Q est centré sur celui de Lateral, son anneau n'est donc pas tout à fait à la place de celui du O (22 millièmes d'écart au plus, en Expanded Regular).
- Dans la base, Ø et surtout Œ n'ont pas le côté gauche du O dans une partie des styles. Avec le même crénage, le blanc après X y reste plus large que devant O : jusqu'à 84 millièmes pour Ø (UltraWide Black Italic), 30 en médiane et jusqu'à 137 pour Œ (UltraWide Regular Italic).

## Méthode

Chaque contour est écrit point par point à partir du glyphe XG Flex du même style, sans opération booléenne.
Lateral ne fournit que des cotes (positions, angles, tension des courbes, épaisseurs, blancs), mesurées par `latfeat.py`.
Pour le crénage de X G, `pairkern.py` mesure le blanc entre les deux lettres dans Lateral et dans XG Flex, à 97 hauteurs de la capitale, puis règle le crénage de XG Flex pour que les deux blancs soient égaux. X C, X O, X Q, X Ø et X Œ sont liées à X G : elles prennent sa valeur, sans mesure. La table de crénage de Lateral n'est pas recopiée.
Aucun contour de Lateral n'est stocké ni repris, et cette archive ne contient aucun fichier de Lateral.

## Reconstruire

Python 3 avec fontTools, numpy, freetype-py, Pillow, brotli et uharfbuzz.

1. Placer les fonts de Lateral dans `scripts/data/lateral/` et le dossier `XG Flex` de la base (version v3) dans `scripts/data/xg_v4/`.
2. Depuis `scripts/` :

```
python cg/latfeat.py                            # mesure les cotes de Lateral dans out/cg/latfeat.json
python cg/pairkern.py out/cg/pairkern.json XG XO=XG XC=XG XQ=XG XØ=XG XŒ=XG   # mesure le blanc entre X et G, calcule son crénage dans chaque style et le donne aux paires liées
python cg/build_custom.py out/cg/full all       # construit les 98 fonts
python cg/mkwoff2.py out/cg/full out/cg/woff2   # les mêmes fonts en WOFF2
python cg/audit.py out/cg/full out/cg/audit.json        # recouvrement avec Lateral, raccords, approches
python cg/gapcheck.py out/cg/full out/cg/gap_full.json  # ouverture du 6 et du 9 face à Lateral
python cg/punctcheck.py out/cg/full out/cg/punctcheck.json   # ponctuation et signes : sens des contours, croisements, blancs, approches face à la base
python cg/contact.py out/cg/full planches 170           # planches des 98 styles
```

`out/T_v4.json` donne, pour chaque style, l'écart de chasse entre la base et Lateral (l'interlettrage de la base).

Deux contrôles du crénage. Le premier relit chaque paire de glyphes des fonts face à la base : seules les paires de la table ont changé, et elles ont toutes la valeur voulue. Le second mesure le crénage par mise en forme du texte, en comparant avec des fonts construites sans ce réglage :

```
python cg/kernfull.py out/cg/full
python cg/build_custom.py out/cg/sans_crenage all 692QaRqpo
python cg/kerncheck.py out/cg/sans_crenage out/cg/full
```

La version et la date écrites dans les fonts sont les constantes `VERSION` et `DATE`, en tête de `build_custom.py`.

Le troisième argument de `build_custom.py` choisit ce qui est construit : `6 9 2 Q a R` pour ces glyphes, `q` pour la virgule, l'apostrophe et leurs dérivés, `p` pour les points, ? et !, `o` pour les signes de calcul, `k` pour le crénage. Sans cet argument, tout est construit.

Pour comparer deux séries de fonts glyphe par glyphe, et voir côte à côte un texte dans plusieurs séries :

```
python cg/diffbuild.py out/cg/avant out/cg/full
python cg/strip.py bande.png 120 "Hi?!.:;" StandardRegular,StandardHeavy "Avant=out/cg/avant" "Après=out/cg/full"
```

Réglages qui tiennent en une ligne :

- dose de la virgule et de l'apostrophe : `XG_COMMA_BLEND=0.25 python cg/build_custom.py out/cg/essai all` (0 pour le trapèze seul, 1 pour la forme de Roboto, 0.10 par défaut) ;
- forme des points : `XG_DOTS=rect` pour les rectangles de Lateral, `XG_DOTS=base` pour garder les points de la base, `round` par défaut ;
- tige du ! : `XG_EXCLAM_TAPER=0.8` pour une tige qui s'amincit vers le bas (largeur du bas rapportée à celle du haut, 1.0 par défaut) ;
- axe des signes de calcul : `XG_MATH_AXIS=0.5` pour le placer à mi-hauteur des capitales (0.463 par défaut, la hauteur de XG Flex) ;
- chasse du a : dans `build_custom.py`, fonction `doa`, remplacer la ligne `adv_new=...` par `adv_new=adv` pour revenir à la chasse de Lateral ;
- hauteur de la coupe du 6 et du 9 : dans `recipes.py`, passer `split=False` par défaut dans la signature de `make_six` pour reprendre la hauteur de Lateral telle quelle ;
- crénage : sans le fichier `out/cg/pairkern.json`, le build garde le crénage de XG Flex. Dans la commande de `pairkern.py`, une paire écrite seule (`XG`, `AV`) est mesurée sur Lateral. Une paire écrite `XO=XG` prend la valeur de la paire nommée après le signe égal, qui doit être donnée avant elle. Pour que X O, X C et X Q aient chacune leur blanc mesuré plutôt que la valeur de X G, les écrire sans le signe égal.
